def test_function():
    variable = "test "
    return variable
